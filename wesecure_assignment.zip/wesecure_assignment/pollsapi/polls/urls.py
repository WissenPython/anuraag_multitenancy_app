from django.urls import path, include
from rest_framework.routers import DefaultRouter

from pollsapi.polls.views import PollsViewSet, VoteViewSet, ChoiceViewSet

router = DefaultRouter()
router.register('polls', PollsViewSet, basename='polls')
router.register('votes', VoteViewSet, basename='votes')
router.register('choices', ChoiceViewSet, basename='choices')

urlpatterns = [
    path('', include(router.urls)),
]